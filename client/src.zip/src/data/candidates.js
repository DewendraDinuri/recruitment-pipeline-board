const candidates = [
  { id: '1', name: 'Marlon Reynolds', appliedDate: '29 Oct, 2023', score: '3.5', referred: true, stage: 'applying', avatar: 'assets/avatar1.png' },
  { id: '2', name: 'Regina Hane', appliedDate: '29 Oct, 2023', score: '2', referred: false, stage: 'applying', avatar: 'assets/avatar2.png' },
  { id: '3', name: 'Curtis Baumbach', appliedDate: '29 Oct, 2023', score: '3.5', referred: true, stage: 'applying', avatar: 'assets/avatar3.png' },
  { id: '4', name: 'Kristi Sipes', appliedDate: '20 Oct, 2023', score: '3.5', referred: false, stage: 'screening', avatar: 'assets/avatar4.png' },
  { id: '5', name: 'Cameron Dickens', appliedDate: '03 Sep, 2023', score: '4', referred: false, stage: 'interview', avatar: 'assets/avatar5.png' }
];

export default candidates;
